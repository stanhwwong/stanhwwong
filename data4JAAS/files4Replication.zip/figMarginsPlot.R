# Figure 3

library(ggplot2)
library(dplyr)

rm(list=ls())


d <- read.csv("dataMarginsPlot.csv", h = T)

d <- d %>% mutate(lb = b - 1.96*se) %>% mutate(ub = b + 1.96*se) 

d$var <- c("Non-HKer, No BNO", "HKer, No BNO", "Non-HKer, BNO", "HKer, BNO")

p <- ggplot(d, aes(y = var, x = b)) + geom_errorbarh(aes(xmax = ub, xmin = lb), height= .1) + ylab("") + xlab("")  + theme(axis.title.y = element_text(size = rel(.7)))  + geom_vline(xintercept = 0, color = "red") + geom_point() + xlab("Migration Intent")
