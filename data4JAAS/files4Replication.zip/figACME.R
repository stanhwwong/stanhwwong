# Figure 6

library(ggplot2)
library(dplyr)

rm(list = ls())

d <- read.csv("dataACME.csv", h = T)

p <- ggplot(d, aes(y = b, x = effect)) + geom_errorbar(aes(ymax = ub, ymin = lb), width=.2 ) + geom_point(shape = 21, fill = "white") + ylab("Estimate") + xlab("") + coord_flip() + geom_hline(yintercept = 0, color = "black") 

