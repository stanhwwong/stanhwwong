library(ggplot2)
library(dplyr)
library(tidyverse)
library(lubridate)

rm(list = ls())


d <- read.csv("data4Figure2.csv", h = T)


d1 <- d %>% mutate(dsSolve = case_when(govsystemsolve == "Strongly disagree" ~ 1, govsystemsolve == "Somewhat disagree" ~ 2, govsystemsolve == "Somewhat agree" ~ 3, govsystemsolve == "Strongly agree" ~ 4), dsSupport = case_when(govsystemsupport == "Strongly disagree" ~ 1, govsystemsupport == "Somewhat disagree" ~ 2, govsystemsupport == "Somewhat agree" ~ 3, govsystemsupport == "Strongly agree" ~ 4), dsSupport2 = case_when(govsystemsupport2 == "Strongly disagree" ~ 1, govsystemsupport2 == "Somewhat disagree" ~ 2, govsystemsupport2 == "Somewhat agree" ~ 3, govsystemsupport2 == "Strongly agree" ~ 4), dsUnder = case_when(govsystemover == "Strongly disagree" ~ 1, govsystemover == "Somewhat disagree" ~ 2, govsystemover == "Somewhat agree" ~ 3, govsystemover == "Strongly agree" ~ 4))

d1 <- d1 %>% group_by(wave) %>% summarise(dsSolveM = mean(dsSolve, na.rm = T), dsSupportM = mean(dsSupport, na.rm = T), dsSupport2M = mean(dsSupport2, na.rm = T), dsUnderM = mean(dsUnder, na.rm = T))

d2 <- d1 %>% filter(wave %in% c(3, 4, 5))

category <- c("Problem-solving","Institutional Pride","Deserve Support","Better Than Others")

d3 <- data.frame(rep(d2$wave, 4), rep(category, each = 3), c(d2$dsSolveM, d2$dsSupportM, d2$dsSupport2M, d2$dsUnderM))

colnames(d3) <- c("wave", "variable", "value")

wave3To5 <- ggplot(d3, aes(x = factor(wave), y = value)) + geom_point(aes(shape = variable)) + xlab("Wave") + ylab("Mean") + labs(shape = "Evaluation Items") + ylim(1.6, 2.2) + ggtitle("Wave 3 - Wave 5")



d5 <- d %>% filter(wave == 5) %>% mutate(newDate = ymd(date), year = year(newDate)) %>% mutate(dsSolve = case_when(govsystemsolve == "Strongly disagree" ~ 1, govsystemsolve == "Somewhat disagree" ~ 2, govsystemsolve == "Somewhat agree" ~ 3, govsystemsolve == "Strongly agree" ~ 4), dsSupport = case_when(govsystemsupport == "Strongly disagree" ~ 1, govsystemsupport == "Somewhat disagree" ~ 2, govsystemsupport == "Somewhat agree" ~ 3, govsystemsupport == "Strongly agree" ~ 4), dsSupport2 = case_when(govsystemsupport2 == "Strongly disagree" ~ 1, govsystemsupport2 == "Somewhat disagree" ~ 2, govsystemsupport2 == "Somewhat agree" ~ 3, govsystemsupport2 == "Strongly agree" ~ 4), dsUnder = case_when(govsystemover == "Strongly disagree" ~ 1, govsystemover == "Somewhat disagree" ~ 2, govsystemover == "Somewhat agree" ~ 3, govsystemover == "Strongly agree" ~ 4), dsChange = case_when(govsystemchange == "Should be replaced" ~ 1, govsystemchange == "Need major change" ~ 2, govsystemchange == "Needs minor change" ~ 3, govsystemchange == "It works fine, not need to change" ~ 4)) %>% mutate(b4NSL = ifelse(year < 2021, 1, 0)) %>% mutate(newAge = year - birthyr)

d6 <- d5 %>% group_by(b4NSL) %>% summarise(dsSolveM = mean(dsSolve, na.rm = T), dsSupportM = mean(dsSupport, na.rm = T), dsSupport2M = mean(dsSupport2, na.rm = T), dsUnderM = mean(dsUnder, na.rm = T), dsChangeM = mean(dsChange, na.rm = T))


category <- c("Problem-solving","Institutional Pride","Deserve Support","Better Than Others")
d7 <- data.frame(rep(c("After", "Before"), length(category)), rep(category, each = 2), c(d6$dsSolveM, d6$dsSupportM, d6$dsSupport2M, d6$dsUnderM))
colnames(d7) <- c("before2021", "variable", "value")

d8 <- d7 %>% mutate(b4NSL = ifelse(before2021 == "After", 0, 1))

withinWave5 <- ggplot(d8, aes(x = reorder(factor(before2021), -b4NSL), y = value)) + geom_point(aes(shape = variable)) + xlab("") + ylab("Mean") + labs(shape = "Evaluation Items") + ggtitle("Wave 5: Before and After NSL") + ylim(1.6, 2.2)


